import matplotlib.pyplot as plt



# Creates histograms
class GraphPlotter:
    def __init__(self, db, username):
        self.db = db
        self.username = username

    def plot_word_histogram(self, word): # For how many times chosen word appears in each file
        data = self.db.query_word(self.username, word)
        if not data:
            print(f"No data found for word '{word}'")
            return

        filenames, counts = zip(*data)
        plt.bar(filenames, counts)
        plt.xticks(rotation=45, ha='right')
        plt.title(f"Occurrences of '{word}'")
        plt.tight_layout()
        plt.show(block=False) # Allows user to continue
        plt.pause(0.001)
        input("Press Enter to return to menu...")  # Wait for user before continuing
        plt.close()


    def plot_all_words_histogram(self):# Plots all words
        data = self.db.get_all_word_frequencies()
        if not data:
            print("No word data available.")
            return

        words, freqs = zip(*data)

        # Limits to prevent crowding
        words = words[:50]
        freqs = freqs[:50]

        plt.figure(figsize=(12, 6))
        plt.bar(words, freqs)
        plt.xticks(rotation=90)
        plt.title("Word Frequencies Across All Files")
        plt.tight_layout()
        plt.show(block=False) # Allows user to continue
        plt.pause(0.001)
        input("Press Enter to return to menu...") # Wait for user before continuing
        plt.close()
