import os
from database import GroceryMongoDB
from textprocess import TextProcessor
from graph import GraphPlotter
from auth import login_menu
from query import query_word

class GroceryApp:
    def __init__(self, username):
        self.username = username
        self.db = GroceryMongoDB(username)
        self.processor = TextProcessor()
        self.grapher = GraphPlotter(self.db, self.username)


    def run(self):
        print(f"Running app as {self.username}") #indicate user
        while True:
            cmd = input("\nOptions:\n1. Process file\n2. Query word count\n3. Plot word histogram\n4. Count all words\n5. Plot all words\nQ. Quit\nChoose: ").upper()
            if cmd == 'Q':
                break
            elif cmd == '1': # Enter name of file and process
                filename= input("Enter path to text file: ")
                full_path = os.path.join("input", filename)

                if os.path.isfile(full_path): # Proceed processing
                    self.process_file(full_path)
                else:
                    print("File not found.")

            elif cmd == '2': # Find occurrences of a specific word
                word = input("Enter word to query: ").lower()
                query_word(self.db, self.username, word)


            elif cmd == '3': # Plot a specific word
                word = input("Enter word to plot: ").lower()
                self.grapher.plot_word_histogram(word)

            elif cmd == '4': # Count all words
                all_words = self.db.get_all_word_frequencies()
                for word, freq in all_words:
                    print(f"{word}: {freq}")

            elif cmd == '5': # Plot all words
                self.grapher.plot_all_words_histogram()

            else:
                print("Invalid option.")


    # File processing
    def process_file(self, filepath):
        filename = os.path.basename(filepath)

        # Check if file is unreasonably large
        max_size_bytes = 5 * 1024 * 1024
        if os.path.getsize(filepath) > max_size_bytes:
            print("File is too large to process (limit is 5 MB).")
            return

        # Read the file safely
        try:
            with open(filepath, 'r', encoding='utf-8') as f:
                raw_text = f.read()
        except UnicodeDecodeError:
            print("File encoding must be UTF-8. Unable to read file.")
            return

        print(f"File '{filename}' successfully uploaded")

        # Tokenizes and counts
        word_counts, _ = self.processor.count_words(raw_text)

        # Ignore if word is unreasonably long
        cleaned_counts = {word: count for word, count in word_counts.items() if len(word) <= 25}

        # Check if file is empty
        if not cleaned_counts:
            print("No valid words found to insert.")
            return

        # Insert counts into MongoDB
        success = self.db.insert_word_counts(filename, cleaned_counts, self.username)
        if success:
            print(f"Processed and inserted '{filename}' with {len(cleaned_counts)} unique words.")
        else:
            print(f"File '{filename}' already processed.")

    # Find a specific word
    def query_word(self, word):
        count = self.db.query_word(word)
        print(f"'{word}' found {count} time(s).")

# Plot a specific word
    def plot_word_histogram(self, word):
        self.grapher.plot_histogram(word)

if __name__ == '__main__':
    user = login_menu() # Start with login
    if user: #when signed in run logic
        app = GroceryApp(user)
        app.run()
else:
        print("Exiting.")
