from pymongo import MongoClient
import datetime


#Handles database
class GroceryMongoDB:
    def __init__(self, username, uri="mongodb://localhost:27017/", db_name="grocerydb"): #Location and name of database
        self.username = username
        self.client = MongoClient(uri)
        self.db = self.client[db_name]
        self.collection = self.db.files
        self.collection.create_index(
            [("username", 1), ("filename", 1)],
            unique=True
        )

    def insert_document(self, username, filename, word_counts, raw_text): #Params of inserted docs
        word_counts_list = [{"word": w, "count": c} for w, c in word_counts.items()]
        doc = {
            "username": username,
            "filename": filename,
            "import_date": datetime.datetime.now(datetime.UTC),
            "word_counts": word_counts,
            "raw_text": raw_text
        }
        self.collection.insert_one(doc) # Counts words in file
        print(f"Inserted '{filename}' for user '{username}' with {len(word_counts)} unique words.")

    def insert_word_counts(self, filename, word_counts, username):
        # Check if file already processed for this user
        if self.is_file_processed(username, filename):
            return False  # Already processed

        doc = {
            "username": username,
            "filename": filename,
            "import_date": datetime.datetime.utcnow(),
            "word_counts": word_counts,
        }
        self.collection.insert_one(doc)
        return True

    def is_file_processed(self, username, filename):
        return self.collection.find_one({"username": username, "filename": filename}) is not None #Checks if file with same name exists

    # Counts specified words
    def query_word(self, username, word):
        cursor = self.collection.find(
            {"username": username, f"word_counts.{word}": {"$exists": True}},
            {"filename": 1, f"word_counts.{word}": 1, "_id": 0}
        )

        return [(doc["filename"], doc["word_counts"].get(word, 0)) for doc in cursor]

    # Counts all words
    def get_all_word_frequencies(self):
        cursor = self.collection.find({"username": self.username}, {"word_counts": 1, "_id": 0})


        total_counts = {}
        for doc in cursor:
            for word, count in doc.get("word_counts", {}).items():
                total_counts[word] = total_counts.get(word, 0) + count

        # Sort by count descending
        sorted_counts = sorted(total_counts.items(), key=lambda x: x[1], reverse=True)
        return sorted_counts

        return sorted(all_counts.items(), key=lambda x: x[1], reverse=True)




