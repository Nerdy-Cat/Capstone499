def query_word(db, username, word):
    results = db.query_word(username, word)  # Word per files uploaded by username
    found = False
    for filename, count in results:
        print(f"{word} appears {count} time(s) in {filename}")
        found = True
    if not found:
        print(f"No entries found for '{word}'.")

