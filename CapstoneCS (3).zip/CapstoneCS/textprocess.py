import re
from collections import Counter

#Handles text processing
class TextProcessor:
    @staticmethod
    def tokenize(text):
        #Convert to lowercase and split on word boundaries
        return re.findall(r'\b\w+\b', text.lower())

    def count_words(self, text):
        #Counts words
        words = self.tokenize(text)
        freq = dict(Counter(words))
        return freq, words