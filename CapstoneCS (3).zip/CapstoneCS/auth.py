import hashlib
import getpass
import sys
from pymongo import MongoClient

class AuthManager:
    def __init__(self):
        self.client = MongoClient()
        self.db = self.client["grocery"]
        self.users = self.db["users"]

    def hash_password(self, password): # Password stored securely
        return hashlib.sha256(password.encode()).hexdigest()

    def register(self, username, password):
        if self.users.find_one({"username": username}):
            return False
        hashed = self.hash_password(password)
        self.users.insert_one({"username": username, "password": hashed})
        return True

    def login(self, username, password):
        hashed = self.hash_password(password)
        user = self.users.find_one({"username": username, "password": hashed})
        return bool(user)



def login_menu(): # Menu for user to create acc or login
    auth = AuthManager()

    while True:
        print("1. Login")
        print("2. Register")
        print("3. Exit")
        choice = input("Choose an option: ").strip()

        if choice == "1": # Returning user
            for attempt in range(3, 0, -1):
                username = input("Username: ").strip()
                password = input("Password: ").strip()
                if auth.login(username, password):
                    print(f"Welcome, {username}!")
                    return username  # success: return the logged-in username
                else:
                    print(f"Login failed. {attempt - 1} attempts remaining.")
            print("Too many failed attempts.")
            return None

        elif choice == "2": #New user
            username = input("Choose a username: ").strip()
            password = input("Password: ").strip()

            if auth.register(username, password):
                print("Registration successful!")
            else:
                print("Username already exists.")

        elif choice == "3":
            return None

        else:
            print("Invalid choice.")
